#!/bin/bash
source ./app/wazuh_prechecks.sh

# Usage Function
usage() {
  cat <<EOF

    Usage:
    wazuh-agent.sh [options]

    options:
    -e  Environment (prod / test)

    Example:
    main.sh -e prod   Install Wazuh on Production environment
    main.sh -e test   Install Wazuh on Testing environment

EOF
}

# Flags
while getopts e:h args
do
    case $args in
        e) environment="$OPTARG";;
        *) usage; exit 0 ;;
    esac
done
shift "$(($OPTIND -1))"

# Main Function
main(){
    if [ "$environment" = "prod" ] || [ "$environment" = "test" ]; then
        echo "Running pre check.."
        pre_check
    else
        usage
        exit 0;
    fi
}

main