# Wazuh Installer

Scripts prepared to install Wazuh agent

# Install

There are two ways to upload the script:

## Automatically

Run the next script:

````
upload_script.py -u USERNAME -p PAT
````

To get the PAT (Personal Access Token), you can follow the next [documentation](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-fine-grained-personal-access-token)

Afterwards, it'll returns an url to run on server.

## Manually

1) Download the zip file into your local computer:

https://github.com/mercadolibre/fury_wazuh-installer/archive/refs/heads/master.zip

2) While connected to the VPN, run the next command

````
curl -XPOST https://runsec.meliseginf.com/links\?file_name\=fury_wazuh-installer-master.zip
````

This command will give us a JSON with 2 urls: **put_url** to publish the file and **get_url** to download it in the server.

3) Publish the file in a S3 so we can download it after

````
curl -XPUT -T fury_wazuh-installer-master.zip <PUT_URL>
````

4) From the destination server, download the script:

````
curl -XGET -o fury_wazuh-installer-master.zip <GET_URL>
````

Note: it's highly recommended to test if it's possible to execute this CURL and download the file. If it works properly, copy and paste the command to execute it from the server (sometimes characters in server are not escaped and generates error).

5) Unzip the file in the server:

````
unzip fury_wazuh-installer-master.zip
````

For more details please refer to the following documentation: https://docs.google.com/document/d/1Afqj6OZOioJQfC2vlPLy94UIBcJLDve2Vnb7pbJjkkw/edit

## Install

````bash
sh main.sh -e <wazuh_environment>
````

Example 

````bash
sh main.sh -e test
````
