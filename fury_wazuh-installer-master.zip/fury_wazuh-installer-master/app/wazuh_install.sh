#!/bin/bash

#Declared Vars
ARCH_SO=$(uname -m)
WAZUH_VERSION=4.4.1-1
PROD_WAZUH_MANAGER='10.61.77.47'
PROD_WAZUH_REGISTRATION_PASSWORD='2d5740919e89da6d60bf1daa64ac33b274ee4b2c0d4f9e2c7c0e91ccda7280b8'
PROD_WAZUH_AGENT_GROUP='FPS'
TEST_WAZUH_MANAGER='10.61.77.36'
TEST_WAZUH_REGISTRATION_PASSWORD='#pn3GcV_pLyWL'
TEST_WAZUH_AGENT_GROUP='SAP_dev,default'

agent_installer(){
# This function allows to install Wazuh agent, using the environment (-e) previously requested on main.sh as an arg.
if [ "$environment" = "prod" ]; then
echo "Installing Wazuh Agent.."
    sudo WAZUH_MANAGER=$PROD_WAZUH_MANAGER WAZUH_REGISTRATION_PASSWORD=$PROD_WAZUH_REGISTRATION_PASSWORD WAZUH_AGENT_GROUP=$PROD_WAZUH_AGENT_GROUP rpm -i https://packages.wazuh.com/4.x/yum/wazuh-agent-"$WAZUH_VERSION".$ARCH_SO.rpm
elif [ "$environment" = "test" ]; then
    sudo WAZUH_MANAGER=$TEST_WAZUH_MANAGER WAZUH_REGISTRATION_PASSWORD=$TEST_WAZUH_REGISTRATION_PASSWORD WAZUH_AGENT_GROUP=$TEST_WAZUH_AGENT_GROUP rpm -i https://packages.wazuh.com/4.x/yum/wazuh-agent-"$WAZUH_VERSION".$ARCH_SO.rpm
else
    usage
    exit 0;
fi
restart_services
}

restart_services(){
# This function restart the services declared below.
    echo "Restarting daemon-reload service.."
    sudo systemctl daemon-reload
    echo "Enabling wazuh-agent service.."
    sudo systemctl enable wazuh-agent
    echo "Starting wazuh-agent service.."
    sudo systemctl start wazuh-agent
    echo "Restarting auditd service"
    sudo service auditd restart
    echo "Restarting rsyslog service"
    sudo service rsyslog restart
    echo "Done!"
    post_install
}

post_install(){
# This function allows to check services post installation.
# Wazuh Agent Service
service wazuh-agent status 2>/dev/null
    if [ $? = 0 ]; then 
        echo Wazuh services are running.; 
    else 
        echo There is a Wazuh service not running correctly. Please run '"service wazuh-agent status"' to verify the affected process.; 
    fi
# Auditd Service
service auditd status 2>/dev/null|grep "Active: active (running)" >/dev/null
    if [ $? = 0 ]; then 
        echo Auditd services is running.; 
    else 
        echo The Auditd service is not running correctly. Please run '"service auditd status"' to verify the affected processs.; 
    fi
# Rsyslog Service
service rsyslog status 2>/dev/null|grep "Active: active (running)" >/dev/null
    if [ $? = 0 ]; then 
        echo rsyslog services is running.; 
    else 
        echo The Rsyslog service is not running correctly. Please run '"service rsyslog status"' to verify the affected processs.;
    fi
    echo "Waiting connection to be established"
    sleep 30
    LOCAL_IP=$(ss -atn '( dport = :1514 )'|grep -v State|grep ESTAB|awk '{print $4}'|awk -F: '{print $1}')
    REMOTE_IP=$(ss -atn '( dport = :1514 )'|grep -v State|grep ESTAB|awk '{print $5}'|awk -F: '{print $1}')
    WAZUH_AGENT_STATUS=$(ss -atn '( dport = :1514 )'|grep -v State|awk '{print $1}')
    echo Connection Status:
    echo LOCAL_IP: "$LOCAL_IP"
    echo REMOTE_IP: "$REMOTE_IP"
    echo PORT: 1514
    if [ "$WAZUH_AGENT_STATUS" = "ESTAB" ]; then 
        echo STATUS: CONNECTED; 
    else 
        echo STATUS: DISCONNECTED; 
    fi
}

wazuh_install(){
    agent_installer
}
