#!/bin/bash

# Import sources
source ./app/wazuh_install.sh

# Declared vars
# Auditd config file
SRC_DIR_AUDITD_RULE_CUSTOM_FILE='./resources/wazuh_auditd'
DST_DIR_AUDITD_RULE_CUSTOM_FILE='/etc/audit/rules.d/audit.rules'
# Logrotate config file
SRC_DIR_LOGROTATE_CUSTOM_FILE='./resources/wazuh_logrotate'
DST_DIR_LOGROTATE_CUSTOM_FILE='/etc/logrotate.d/'
# Rsyslog config file
SRC_DIR_RSYSLOG_CUSTOM_FILE='./resources/wazuh_rsyslog.conf'
DST_DIR_RSYSLOG_CUSTOM_FILE='/etc/rsyslog.d/wazuh_rsyslog.conf'
# Audispd-plugins auditd config file
SRC_DIR_AUDISPD_PLUGINS_AUDITD_CONF_FILE='./resources/audispd-plugins/auditd.conf'
DST_DIR_AUDISPD_PLUGINS_AUDITD_CONF_FILE='/etc/audit/auditd.conf'
# Audispd-plugins syslog config file
SRC_DIR_AUDISPD_PLUGINS_SYSLOG_CONF_FILE='./resources/audispd-plugins/syslog.conf'
DST_DIR_AUDISPD_PLUGINS_SYSLOG_CONF_FILE='/etc/audit/plugins.d/syslog.conf'
DST_DIR_AUDIT_AUDISP_REMOTE_FILE_RHEL8='/etc/audit/audisp-remote.conf'
DST_DIR_AUDISP_PLUGINS_SYSLOG_RHEL_SUSE='/etc/audisp/plugins.d/syslog.conf'
DST_DIR_AUDISP_AUDISPD_RHEL_SUSE='/etc/audisp/audispd.conf'
# Get OS Distribution
OS_RELEASE=$(grep PRETTY_NAME /etc/os-release)
DATE=_bkp_$(date +"d%m%Y_%H%M%S")

# Pre Check Functions
pre_check_os(){
# This function allows to get the package manager based on the distribution.
    echo "Step 1: Verify OS Distribution"
    if [[ $OS_RELEASE == *"Ubuntu"* ]] || [[ $OS_RELEASE == *"Debian"* ]]; then PACKAGE_INSTALL="apt install -y" PACKAGE_REMOVE="apt remove -y";
    elif [[ $OS_RELEASE == *"Oracle"* ]] || [[ $OS_RELEASE == *"Red Hat"* ]]; then PACKAGE_INSTALL="yum install -y" PACKAGE_REMOVE="yum remove -y";
    elif [[ $OS_RELEASE == *"SUSE"* ]]; then PACKAGE_INSTALL="zypper -n install" PACKAGE_REMOVE="zypper -n rm";
    echo "·····················································"
    echo "$OS_RELEASE detected"
    else echo "Couldn't be able to obtain the package distribution"
    fi
    pre_check_previous_install
}

pre_check_previous_install(){
# This function will check previous wazuh agent installation
    echo "Step 2: Verify previous wazuh installation"
    rpm -e "$(rpm -qa|grep -i wazuh)"
    pre_check_config_files
}


pre_check_config_files(){
# This function allows to set the config files rules for auditd / rsyslog services. 
    echo "·····················································"
    echo "Step 3: Setting config files"
    echo "Setting Auditd config file"
    
    ls $DST_DIR_AUDITD_RULE_CUSTOM_FILE > /dev/null 2>&1
    if [ $? = 0 ]; then
    echo "Previous $DST_DIR_AUDITD_RULE_CUSTOM_FILE file detected. Creating a backup"
    mv $DST_DIR_AUDITD_RULE_CUSTOM_FILE $DST_DIR_AUDITD_RULE_CUSTOM_FILE$DATE
    fi
    cp $SRC_DIR_AUDITD_RULE_CUSTOM_FILE $DST_DIR_AUDITD_RULE_CUSTOM_FILE
    
    echo "Setting /var/log/elsa output on /etc/rsyslog.conf"
    ls $DST_DIR_RSYSLOG_CUSTOM_FILE > /dev/null 2>&1
    if [ $? = 0 ]; then
    echo "Previous $DST_DIR_RSYSLOG_CUSTOM_FILE file detected. Creating a backup"
    mv $DST_DIR_RSYSLOG_CUSTOM_FILE $DST_DIR_RSYSLOG_CUSTOM_FILE$DATE
    fi
    cp $SRC_DIR_RSYSLOG_CUSTOM_FILE $DST_DIR_RSYSLOG_CUSTOM_FILE
    
    echo "Create logrotate_meli file"
    cp $SRC_DIR_LOGROTATE_CUSTOM_FILE $DST_DIR_LOGROTATE_CUSTOM_FILE
    
    echo "Create audisp config"
    if [[ $OS_RELEASE == *"Red Hat Enterprise Linux 8"* ]]; then
        cp $DST_DIR_AUDIT_AUDISP_REMOTE_FILE_RHEL8 $DST_DIR_AUDIT_AUDISP_REMOTE_FILE_RHEL8$DATE
        sed -i 's/^priority_boost.*/priority_boost = 8/g' $DST_DIR_AUDIT_AUDISP_REMOTE_FILE_RHEL8
        sed -i 's/^q_depth.*/q_depth = 4096/g' $DST_DIR_AUDIT_AUDISP_REMOTE_FILE_RHEL8
        cp $SRC_DIR_AUDISPD_PLUGINS_AUDITD_CONF_FILE $SRC_DIR_AUDISPD_PLUGINS_AUDITD_CONF_FILE$DATE
        cp $SRC_DIR_AUDISPD_PLUGINS_AUDITD_CONF_FILE $DST_DIR_AUDISPD_PLUGINS_AUDITD_CONF_FILE
        cp $SRC_DIR_AUDISPD_PLUGINS_SYSLOG_CONF_FILE $SRC_DIR_AUDISPD_PLUGINS_SYSLOG_CONF_FILE$DATE
        cp $SRC_DIR_AUDISPD_PLUGINS_SYSLOG_CONF_FILE $DST_DIR_AUDISPD_PLUGINS_SYSLOG_CONF_FILE
    else
        cp $DST_DIR_AUDISP_PLUGINS_SYSLOG_RHEL_SUSE $DST_DIR_AUDISP_PLUGINS_SYSLOG_RHEL_SUSE$DATE
        sed -i 's/^active.*/active = yes/g' $DST_DIR_AUDISP_PLUGINS_SYSLOG_RHEL_SUSE
        cp $DST_DIR_AUDISP_AUDISPD_RHEL_SUSE $DST_DIR_AUDISP_AUDISPD_RHEL_SUSE$DATE
        sed -i 's/^q_depth.*/q_depth = 4096/g' $DST_DIR_AUDISP_AUDISPD_RHEL_SUSE
    fi
    
    echo "Validate if server contains ABAP / JAVA / HANA Apps"
    export SID="$(echo ${HOSTNAME:3:3}|sed 's/[a-z]/\U&/g')"
    # TODO Add SID with sapsm0db01 
    export IS_DB="$(echo ${HOSTNAME:6:2}|sed 's/[a-z]/\U&/g')"
    ps -ef | grep "hdbnameserver" | grep -v grep | wc -l 2>/dev/null
    if [ $? != 0 ] || [ "$(ls /usr/sap/$SID/ |grep '^D\|^J')" ] || [ "$IS_DB" == "DB" ]; then
    cat <<-EOF > $DST_DIR_RSYSLOG_CUSTOM_FILE 

authpriv.*;auth.* -/var/log/elsa

if (\$programname contains 'audisp' or \$syslogtag contains 'audisp') and not (\$msg contains 'wazuh') and (\$msg contains 'key=\"elsa') then {
  -/var/log/elsa
  stop
}

if (\$programname startswith 'HDB') then {
  -/var/log/elsa
  stop
}
EOF
fi

    echo "Validate if server is a RHEL OS"
    if [[ $OS_RELEASE == *"Red Hat"* ]]; then
    export SID="$(echo ${HOSTNAME:3:3}|sed 's/[a-z]/\U&/g')"
    echo $SID
    which /usr/sap/${SID}/SYS/exe/run/tp
    echo -e "\n### TP Import execution\n-w /usr/sap/${SID}/SYS/exe/run/tp -p x -k elsa_tp_hive\n### Profile Parameters\n-w /usr/sap/${SID}/SYS/profile -p w -k elsa_profile_hive" | tee -a $DST_DIR_AUDITD_RULE_CUSTOM_FILE
    export sidadm=${HOSTNAME:3:3}adm
    export rule=$(runuser -l  ${sidadm} -c 'which tp')
    echo -e "\n-w $rule -p x -k elsa_tp_hive" | tee -a $DST_DIR_AUDITD_RULE_CUSTOM_FILE
    else
    echo "The server is not a RHEL OS"
    fi
    
    pre_check_services
    }

pre_check_services(){
# This function allows to set services
    echo "·····················································"
    echo "Step 4: Check services"
    echo "Check if auditd service is installed"
    service auditd status 2>/dev/null|grep "Active: active (running)" >/dev/null
    if [ $? = 0 ]; then echo "Auditd Service is active ";
    else echo "Auditd service not found. Preparing to install"
    $PACKAGE_INSTALL auditd
    fi
    
    echo "Check if autispd plugins is installed"
    service audisp status 2>/dev/null|grep "Active: active (running)" >/dev/null
    if [ $? = 0 ]; then echo "Audisp-plugin Service is active ";
    else echo "Audisp-plugin service not found. Preparing to install"
    if [[ $OS_RELEASE == *"SUSE"* ]]; then
    $PACKAGE_INSTALL audit-audispd-plugins
    else
    $PACKAGE_INSTALL audispd-plugins
    fi
    fi
    
    echo "Check for previous wazuh agent installation"
    if [ "$(service wazuh-agent status 2>/dev/null| grep "is running" | wc -l)" = 5 ]; then
        echo "Previous Wazuh-Agent installation detected, removing wazuh-agent package"
        $PACKAGE_REMOVE wazuh-agent
    else echo "Wazuh-Agent not detected"
    fi

    pre_check_done
}

pre_check_done(){
# This function calls the installer function located on ./app/wazuh-install.sh
    echo "·····················································"
    echo "Pre Check Done!"
    wazuh_install
}

pre_check(){
    pre_check_os 
}
