import os
import argparse
import requests

PWD = os.getcwd()
REPO_OWNER = 'mercadolibre'
REPO_NAME = 'fury_wazuh-installer'
FILENAME='fury_wazuh-installer-master.zip'
FILE_PATH = f'{PWD}/{FILENAME}'

def get_github_repository(USERNAME, PASSWORD):
    """This function allows to clone the github repository 
    Keyword arguments:
    param -- Github Username and Password
    Return: File downloaded in directory where the script is running
    """
    DOWNLOAD_URL = f'https://github.com/{REPO_OWNER}/{REPO_NAME}/archive/master.zip'
    # Create a session to manage authentication
    session = requests.Session()
    session.auth = (USERNAME, PASSWORD)
    response = session.get(DOWNLOAD_URL)
    # Save the ZIP file to local disk
    with open(FILE_PATH, 'wb') as file:
        file.write(response.content)
    if response.status_code == 200:
        print(f'File saved in {FILE_PATH}')
        upload_file()
    else:
        print(f"There was an error while trying to upload the file. Status code: {response.status_code}")
        
def upload_file():
    """This function allows to upload the file downloaded from the get_github_repository function.
    
    Keyword arguments:
    Return: curl link
    """
    URL = f'https://runsec.meliseginf.com/links\?file_name\={FILENAME}'
    resp_runsec = requests.post(URL).json()
    #Get the response for runsec
    PUT_URL = resp_runsec['put_url']
    GET_URL = resp_runsec['get_url']
    upload_url = requests.put(PUT_URL, data=open(FILE_PATH,'rb'))
    if upload_url.status_code == 200:
        print('Upload successful, generating link: ')
        print(f'curl -XGET -o {FILENAME} {GET_URL}')
    else:
        print(f"There was an error while trying to upload the file. Status code: {upload_url.status_code}")

def help():
    print("Options: ")
    print("-u, --username   Github Username")
    print("-p, --password   Github PAT (Personal Access Token)")
    exit()

def get_args():
    """
    This function allows to get the args to be used in next functions.
    """
    parser = argparse.ArgumentParser(description='Set Github username and password')
    parser.add_argument('-u', '--username', type=str, help='Github Username')
    parser.add_argument('-p', '--password',type=str, help='Github PAT (Personal Access Token)')
    args = parser.parse_args()

    if args.username is not None and args.password is not None:
        print({args.username}, {args.password})
        get_github_repository(args.username,args.password)
    else:
        help()

def main():
    """
    Main function
    """
# Initialize the argument parser
    get_args()

main()